#include "book.h"

#include <iostream>
#include <QString>

using namespace std;

//Book::Book()
//{
//    price = '\0';
//	ISBN = '\0';
//	title = '\0';
//	author = '\0';
//	edition = '\0';
//    classNumber = '\0';
//	condition = '\0';
//	department = '\0';
//}

